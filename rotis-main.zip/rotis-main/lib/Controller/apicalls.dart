import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:foodapp/Model/cart.dart';
import 'package:foodapp/Model/response.dart';
import 'package:foodapp/View/Model/shared_prefs.dart';
import 'package:http/http.dart' as http;

class ApiCalls {
  static String id = "1";
  static String token = "";
  static String contentType = "application/json";
  static String apiKey = "EX3hAgMk3IMktRDhOoodZXSk3anBk3UR";
  static String baseUrl = "http://ots.logic-valley.com/api/";
  static String loginUrl = "user/login";
  static String checkTokenUrl = "user/token-validate";
  static String contactsUrl = "contacts";
  static String menuUrl = "restaurant/menus";
  static String todayOrdersUrl = "user/listing-orders-today";
  static String openOrderListUrl = "user/listing-orders-open";
  static String allOrderListUrl = "user/listing-orders";
  static String createOrderUrl = "restaurant/create-order";
  static String orderDetailsUrl = "user/details-order";
  static String editOrderUrl = "restaurant/update-order";
  static String orderCancelUrl = "user/cancel-order";
  static String orderServedUrl = "user/collect-order";
  static String logoutUrl = "user/token-expire";

  static Future<bool> _checkInternetConnection() async {
    bool connectivityCheck = false;
    try {
      final result = await InternetAddress.lookup('google.com')
          .timeout(const Duration(seconds: 20));
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        log('connected');
        connectivityCheck = true;
      }
    } on SocketException catch (_) {
      log('not connected');
      connectivityCheck = false;
    }

    return connectivityCheck;
  }

  static Future<Response> getUserDetails(
      {required String username, required String password}) async {
    bool connection = await _checkInternetConnection();
    Response r = Response();
    if (connection) {
      try {
        var url = Uri.parse(baseUrl + loginUrl);
        var response = await http.post(url, headers: {
          'key': apiKey,
        }, body: {
          'username': username,
          'password': password,
        });

        Map<String, dynamic> result = jsonDecode(response.body);
        r.code = result["code"];
        r.status = result["status"];
        r.message = result["message"];
        r.data = result["data"];
        token = r.data["token"];
        SharedPrefs.saveUserData(token: token);

        return r;
      } catch (e) {
        r.status = false;
        log("error: $e");
        return r;
      }
    } else {
      return r;
    }
  }

  static Future<Response> checkToken() async {
    bool connection = await _checkInternetConnection();
    Response r = Response();
    log("Token: $token");
    if (connection) {
      try {
        var url = Uri.parse(baseUrl + checkTokenUrl);
        var response = await http.post(url, headers: {
          'key': apiKey,
          'token': token,
        }, body: {});

        Map<String, dynamic> result = jsonDecode(response.body);
        r.code = result["code"];
        r.status = result["status"];
        r.message = result["message"];

        return r;
      } catch (e) {
        r.status = false;
        log("error: $e");
        return r;
      }
    } else {
      return r;
    }
  }

  static Future<Response> getMenuDetails() async {
    Response r = Response();
    try {
      var url = Uri.parse(baseUrl + menuUrl);
      var response = await http.post(url, headers: {
        'key': apiKey,
      }, body: {
        'id': id
      });

      Map<String, dynamic> result = jsonDecode(response.body);
      //r.code=result["code"];
      r.status = result["status"];
      r.message = result["message"];
      r.data = result["data"];

      return r;
    } catch (e) {
      r.status = false;
      log("error: $e");
      return r;
    }
  }

  static Future<Response> placeOrder(String tableId) async {
    List<Map<String, dynamic>> items = [];

    for (int i = 0; i < Cart.cartItems.length; i++) {
      items.add(Cart.cartItems[i].toJsonOrderFormat());
    }

    Map<String, dynamic> body1 = {
      'id': id, // what the ??
      'table_id': tableId,
      'items': items,
    };
    String res = jsonEncode(body1);

    Response r = Response();
    try {
      var url = Uri.parse(baseUrl + createOrderUrl);
      var response = await http.post(url,
          headers: {
            'key': apiKey,
            'token': token,
            'Content-Type': contentType,
          },
          body: res);

      Map<String, dynamic> result = jsonDecode(response.body);
      //r.code=result["code"];
      r.status = result["status"];
      r.message = result["message"];
      r.data = result["data"];

      return r;
    } catch (e) {
      r.status = false;
      log("error: $e");
      return r;
    }
  }

  static Future<Response> getOrderDetails(String tableId, int orderType) async {
    String apiUrl = "";
    if (orderType == 0) {
      // order history
      apiUrl = baseUrl + allOrderListUrl;
    } else if (orderType == 1) {
      // today orders
      apiUrl = baseUrl + todayOrdersUrl;
    } else {
      // open orders
      apiUrl = baseUrl + openOrderListUrl;
    }
    Response r = Response();
    try {
      var url = Uri.parse(apiUrl);
      var response = await http.post(url, headers: {
        'key': apiKey,
        'token': token,
      }, body: {
        'table_id': tableId, //change later
        'page': "1",
        'limit': "15"
      });

      Map<String, dynamic> result = jsonDecode(response.body);
      r.code = result["code"];
      r.status = result["status"];
      r.message = result["message"];
      r.data = result["data"];

      return r;
    } catch (e) {
      r.status = false;
      log("error: $e");
      return r;
    }
  }

  static Future<Response> getContactDetails() async {
    Response r = Response();
    try {
      var url = Uri.parse(baseUrl + contactsUrl);
      var response = await http.post(url, headers: {
        'key': apiKey,
      }, body: {});

      Map<String, dynamic> result = jsonDecode(response.body);
      r.code = result["code"];
      r.status = result["status"];
      r.message = result["message"];
      r.data = result["data"];

      return r;
    } catch (e) {
      r.status = false;
      log("error: $e");
      return r;
    }
  }

  static Future<Response> logOut() async {
    Response r = Response();
    try {
      var url = Uri.parse(baseUrl + logoutUrl);
      var response = await http.post(url, headers: {
        'key': apiKey,
        'token': token,
      }, body: {});

      Map<String, dynamic> result = jsonDecode(response.body);
      r.code = result["code"];
      r.status = result["status"];
      r.message = result["message"];
      r.data = result["data"];

      return r;
    } catch (e) {
      r.status = false;
      log("error: $e");
      return r;
    }
  }

  static Future<String> generateBillAPI(String ids) async {
    bool connection = await _checkInternetConnection();
    if (connection) {
      try {
        var url = Uri.parse(baseUrl + orderServedUrl);
        var response = await http.post(url, headers: {
          'key': apiKey,
          'token': token,
        }, body: {
          'id': ids
        });

        Map<String, dynamic> result = jsonDecode(response.body);
        return result['message'];
      } catch (e) {
        log("error: $e");
        return "Unable to process request at the moment";
      }
    } else {
      return "No internet connection found";
    }
  }

  static Future<bool> orderCancelMethod({int? id}) async {
    // Response r = Response();
    try {
      var url = Uri.parse(baseUrl + orderCancelUrl);
      var response = await http.post(url, headers: {
        'key': apiKey,
        'token': token,
      }, body: {
        'id': id.toString(),
      });
      var data = jsonDecode(response.body);
      print('data is === $data');
      if (data['status'] == true) {
        log('Response code is ==${response.statusCode}');

        return true;
      }
      return false;

      // Map<String, dynamic> result = jsonDecode(response.body);
      // r.code = result["code"];
      // r.status = result["status"];
      // r.message = result["message"];
      // r.data = result["data"];

    } catch (e) {
      print(e.toString());
      return false;
      // r.status = false;
      // log("error: $e");
      // return false;
    }
  }
}
