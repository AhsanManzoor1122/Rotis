import 'package:flutter/material.dart';

import 'sizeconfig.dart';

//The theme class handles all the text styles,button themes,basic colors etc
ThemeData basicTheme() {
  TextTheme _basicTextTheme(TextTheme base) {
    return base.copyWith(
      headline1: base.headline1!.copyWith(
        fontSize: SizeConfig.width25,
        color: Colors.white,
        fontWeight: FontWeight.bold,
      ),
      button: base.headline1!.copyWith(
        fontSize: SizeConfig.width18,
        color: Colors.white,
        fontWeight: FontWeight.bold,
      ),
      // headline2: base.headline1.copyWith(
      //   fontSize: SizeConfig.thirtyMultiplier,
      //   color: Colors.black,
      //   fontWeight: FontWeight.normal,
      // ),
      // headline3: base.headline1.copyWith(
      //   fontSize: SizeConfig.twentyMultiplier,
      //   color: Colors.white,
      //   fontWeight: FontWeight.normal,
      // ),
      // headline4: base.headline1.copyWith(
      //   fontSize: SizeConfig.twentyMultiplier,
      //   color: Colors.black,
      //   fontWeight: FontWeight.normal,
      // ),
      // headline5: base.headline1.copyWith(
      //   fontSize: SizeConfig.twentyFiveMultiplier,
      //   color: Colors.black,
      //   fontWeight: FontWeight.normal,
      // ),
      // //Login Page
      // headline6: base.headline1.copyWith(
      //   fontSize: SizeConfig.twentyFiveMultiplier,
      //   color: Colors.white,
      //   fontWeight: FontWeight.normal,
      // ),
      // bodyText1: base.headline1.copyWith(
      //   fontSize: SizeConfig.eighteenMultiplier,
      //   color: Colors.white,
      //   fontWeight: FontWeight.normal,
      // ),
      // bodyText2: base.headline1.copyWith(
      //   fontSize: SizeConfig.eighteenMultiplier,
      //   color: Colors.black,
      //   fontWeight: FontWeight.normal,
      // ),
      caption: base.headline1!.copyWith(
        fontSize: SizeConfig.width18,
        color: const Color(0xffE92F47),
        fontWeight: FontWeight.bold,
      ),
      // button: base.button.copyWith(
      //   fontWeight: FontWeight.bold,
      //   fontSize: SizeConfig.eighteenMultiplier,
      //   color: Colors.white,
      // ),
    );
  }

  final ThemeData base = ThemeData(primarySwatch: Colors.blueGrey);
  return base.copyWith(
    textTheme: _basicTextTheme(base.textTheme),
    primaryColor: const Color(0xffE92F47),
    // App Bar
    primaryColorLight: Colors.white,
    // Other
    toggleableActiveColor: const Color(0xffE92F47),
    scaffoldBackgroundColor: Colors.white,
    secondaryHeaderColor: Colors.blueGrey.shade700,
    disabledColor: Colors.grey,
    tabBarTheme: base.tabBarTheme.copyWith(
      labelColor: Colors.white,
      unselectedLabelColor: Colors.grey,
    ),
    colorScheme: ColorScheme.fromSwatch().copyWith(secondary: Colors.white),
  );
}
