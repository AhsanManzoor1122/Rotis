import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class StaticViewVariables {
  static bool waiter = false;

  //static bool isLoading = false;

  static showLoaderDialog(BuildContext context) {
    //isLoading = true;
    AlertDialog alert = AlertDialog(
      content: Row(
        children: [
          const CircularProgressIndicator(
            color: Color(0xffE92F47),
          ),
          Container(
              margin: const EdgeInsets.only(left: 7),
              child: const Text("Loading...")),
        ],
      ),
    );
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

/*static hideLoaderDialog() {
    isLoading = false;
  }*/
}
