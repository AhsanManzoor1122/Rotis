import 'package:foodapp/Controller/apicalls.dart';
import 'package:foodapp/Model/staticvariables.dart';
import 'package:shared_preferences/shared_preferences.dart';

// A class to handle shared Preferences
class SharedPrefs {
  static SharedPreferences? _prefs;

  static SharedPreferences? get prefs => _prefs;

  //This function should be called at the main function of the app (main.dart)
  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static String authKeyString = "AUTH_KEY";
  static String tableIDString = "TABLE_ID";
  static String waiterModeString = "WAITER_MODE";

  static void saveUserData({String? token, String? tableID, bool? waiterMode}) {
    if (token != null) {
      SharedPrefs.prefs!.setString(authKeyString, token);
    }
    if (tableID != null) {
      SharedPrefs.prefs!.setString(tableIDString, tableID);
    }
    if (waiterMode != null) {
      SharedPrefs.prefs!.setBool(waiterModeString, waiterMode);
    }
  }

  static void getUserData() {
    String? token = SharedPrefs.prefs!.getString(authKeyString);
    String? tableID = SharedPrefs.prefs!.getString(tableIDString);
    bool? waiterMode = SharedPrefs.prefs!.getBool(waiterModeString);

    if (tableID != null) {
      StaticVariables.selectedTableIdOrderScreen = tableID;
      StaticVariables.selectedTableIdCartScreen = tableID;
    } else {
      StaticVariables.selectedTableIdOrderScreen = "";
      StaticVariables.selectedTableIdCartScreen = "";
    }

    if (token != null) {
      ApiCalls.token = token;
    } else {
      ApiCalls.token = "";
    }

    if (waiterMode != null) {
      StaticVariables.waiterMode = waiterMode;
    } else {
      StaticVariables.waiterMode = false;
    }
  }
}
