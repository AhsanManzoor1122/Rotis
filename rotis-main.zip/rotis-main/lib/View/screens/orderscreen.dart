import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/Controller/apicalls.dart';
import 'package:foodapp/Model/allorders.dart';
import 'package:foodapp/Model/response.dart';
import 'package:foodapp/Model/staticvariables.dart';
import 'package:foodapp/View/Model/sizeconfig.dart';
import 'package:foodapp/View/Model/staticviewvariables.dart';
import 'package:foodapp/View/widgets/expandablebutton.dart';

class OrdersScreen extends StatefulWidget {
  OrdersScreen({Key? key}) : super(key: key);

  @override
  _OrdersScreenState createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  bool buttonStatus = false;

  @override
  void initState() {
    Timer(const Duration(seconds: 1), () async {
      if (StaticVariables.waiterMode) {
        if (StaticVariables.allTables.isNotEmpty) {
          getOrderList(index: 0);
        }
      } else {
        getOrderList();
      }
    });
    super.initState();
  }

  Future<void> getOrderList({int? index}) async {
    if (index != null) {
      StaticVariables.selectedTableIdOrderScreen =
          StaticVariables.allTables[index].id.toString();
    }
    setState(() {
      buttonStatus = true;
      StaticViewVariables.showLoaderDialog(context);
    });
    Response r = await AllOrders.getAllOrders(
        StaticVariables.selectedTableIdOrderScreen, 2);
    if (r.status == true) {
      setState(() {
        AllOrders.calculateTotalValues();
        Navigator.of(context).pop();
        /*print(StaticVariables
                                      .selectedTableIdOrderScreen);*/
      });
    } else {
      setState(() {
        Navigator.of(context).pop();
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
        r.message,
      )));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          flex: 1,
          child: Container(
              padding: const EdgeInsets.symmetric(vertical: 5),
              alignment: Alignment.center,
              child: StaticVariables.waiterMode
                  ? ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: StaticVariables.allTables.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          child: TextButton(
                            style: ButtonStyle(
                                backgroundColor: StaticVariables
                                            .selectedTableIdOrderScreen ==
                                        StaticVariables.allTables[index].id
                                            .toString()
                                    ? MaterialStateProperty.all<Color>(
                                        Theme.of(context).primaryColor)
                                    : MaterialStateProperty.all<Color>(
                                        Theme.of(context).primaryColorLight),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        side: BorderSide(
                                            color:
                                                Theme.of(context).primaryColor)))),
                            onPressed: () => getOrderList(index: index),
                            child: Text(
                              StaticVariables.allTables[index].name!,
                              style:
                                  StaticVariables.selectedTableIdOrderScreen ==
                                          StaticVariables.allTables[index].id
                                              .toString()
                                      ? Theme.of(context).textTheme.button
                                      : Theme.of(context).textTheme.caption,
                            ),
                          ),
                        );
                      })
                  : Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 5),
                      child: TextButton(
                        style: ButtonStyle(
                            backgroundColor: buttonStatus == true
                                ? MaterialStateProperty.all<Color>(
                                    Theme.of(context).primaryColor)
                                : MaterialStateProperty.all<Color>(
                                    Theme.of(context).primaryColorLight),
                            shape: MaterialStateProperty.all<
                                    RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    side: BorderSide(
                                        color:
                                            Theme.of(context).primaryColor)))),
                        onPressed: () => getOrderList(),
                        child: Text(
                          "Table ${StaticVariables.selectedTableIdOrderScreen}",
                          style: buttonStatus == true
                              ? Theme.of(context).textTheme.button
                              : Theme.of(context).textTheme.caption,
                        ),
                      ),
                    )),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Text(
            "Orders List",
            style: TextStyle(
              fontSize: SizeConfig.width18,
              fontWeight: FontWeight.bold,
              decoration: TextDecoration.underline,
              decorationColor: Theme.of(context).primaryColor,
              decorationThickness: 3,
            ),
          ),
        ),
        Expanded(
          flex: 6,
          child: Container(
              padding: const EdgeInsets.symmetric(vertical: 5),
              alignment: Alignment.center,
              child: AllOrders.listOrders.isEmpty
                  ? const Center(
                      child: Text("No orders found"),
                    )
                  : ListView.builder(
                      scrollDirection: Axis.vertical,
                      itemCount: AllOrders.listOrders.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 5),
                            //child: Text("gey"),
                            child: ExpandableButton(
                              index,
                              onSelected: (bool? value) {
                                setState(() {
                                  AllOrders.listOrders[index].isSelected =
                                      value!;
                                  AllOrders.calculateTotalValues();
                                });
                              },
                              getOrderList: () {
                                if (StaticVariables.waiterMode) {
                                  if (StaticVariables.allTables.isNotEmpty) {
                                    int tableIndex = StaticVariables.allTables
                                        .indexWhere((element) =>
                                            element.id.toString() ==
                                            StaticVariables
                                                .selectedTableIdOrderScreen);
                                    getOrderList(
                                        index:
                                            tableIndex >= 0 ? tableIndex : 0);
                                  }
                                } else {
                                  getOrderList();
                                }
                              },
                            ));
                      })),
        ),
        Expanded(
          flex: 4,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Text(
                    "Summary",
                    style: TextStyle(
                      fontSize: SizeConfig.width18,
                      fontWeight: FontWeight.bold,
                      decoration: TextDecoration.underline,
                      decorationColor: Theme.of(context).primaryColor,
                      decorationThickness: 3,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Sub-total"),
                    Text(AllOrders.totalItemsValue.toString()),
                  ],
                ),
                const Divider(thickness: 1),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(StaticVariables.taxTitle![0].toUpperCase() +
                        StaticVariables.taxTitle!.substring(1).toLowerCase()),
                    Text(AllOrders.totalTaxValue.toString()),
                  ],
                ),
                const Divider(thickness: 1),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("Service Charges"),
                    Text(AllOrders.totalServiceCharges.toString()),
                  ],
                ),
                const Divider(thickness: 1),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Total",
                      style: TextStyle(
                        fontSize: SizeConfig.width16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      AllOrders.totalBillValue.toString(),
                      style: TextStyle(
                        fontSize: SizeConfig.width16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: TextButton(
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                            Theme.of(context).primaryColor),
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ))),
                    onPressed: () async {
                      setState(() {
                        StaticViewVariables.showLoaderDialog(context);
                      });
                      String response = await ApiCalls.generateBillAPI(
                          AllOrders.getSelectedIDsString());
                      setState(() {
                        Navigator.of(context).pop();
                      });
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(
                        response,
                      )));
                      if (StaticVariables.waiterMode) {
                        if (StaticVariables.allTables.isNotEmpty) {
                          getOrderList(index: 0);
                        }
                      } else {
                        getOrderList();
                      }
                    },
                    child: Text(
                      "Generate Bill",
                      style: Theme.of(context).textTheme.button,
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
      ],
    );
  }
}
