import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/Model/addons.dart';
import 'package:foodapp/Model/menuitems.dart';
import 'package:foodapp/View/Model/sizeconfig.dart';
import 'package:foodapp/View/widgets/addontile.dart';

class AddOnScreen extends StatefulWidget {
  List<AddOns> aOns = [];
  MenuItems menuItem;

  AddOnScreen(this.menuItem, this.aOns, {Key? key}) : super(key: key);

  @override
  _AddOnScreenState createState() => _AddOnScreenState();
}

class _AddOnScreenState extends State<AddOnScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      appBar: AppBar(
        bottomOpacity: 0.0,
        elevation: 0.0,
        leading: BackButton(
          color: Theme.of(context).primaryColor,
        ),
        actions: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: SizeConfig.width5),
            child: SizedBox(
                height: SizeConfig.height50,
                width: SizeConfig.width50,
                child: const Image(image: AssetImage('assets/logo.png'))),
          ),
        ],
        backgroundColor: Theme.of(context).primaryColorLight,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(5),
            child: Column(
              children: [
                Container(
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        image: NetworkImage(widget.menuItem.imageUrl!),
                        fit: BoxFit.cover,
                      ),
                    ),
                    height: SizeConfig.height150,
                    width: SizeConfig.screenWidth,
                    child: const SizedBox.shrink()),
                SizedBox(height: SizeConfig.height10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      widget.menuItem.name!,
                      style: Theme.of(context).textTheme.caption,
                    ),
                    Text(
                      "Rs. ${widget.menuItem.price.toString()}",
                      style: Theme.of(context).textTheme.caption,
                    ),
                  ],
                ),
                SizedBox(height: SizeConfig.height10),
                Text(
                  widget.menuItem.description!,
                  textAlign: TextAlign.left,
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                  border: Border(
                      top: BorderSide(
                          width: 2, color: Theme.of(context).primaryColor))),
              child: ListView.builder(
                  scrollDirection: Axis.vertical,
                  itemCount: widget.aOns.length,
                  shrinkWrap: true,
                  itemBuilder: (BuildContext context, int index) {
                    return AddOnTile(widget.aOns[index]);
                  }),
            ),
          ),
          Container(
            height: SizeConfig.height60,
            color: Theme.of(context).primaryColor,
            child: Row(
              children: [
                Expanded(
                  flex: 4,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      SizedBox(
                        height: SizeConfig.height35,
                        child: FloatingActionButton(
                          heroTag: 'DEF',
                          child:
                              const Icon(Icons.remove, color: Colors.black87),
                          backgroundColor: Colors.white,
                          onPressed: () {
                            setState(() {
                              if (widget.menuItem.quantity > 1) {
                                widget.menuItem.quantity--;
                              }
                            });
                          },
                        ),
                      ),
                      Text(
                        '${widget.menuItem.quantity}',
                        style: Theme.of(context).textTheme.button,
                      ),
                      SizedBox(
                        height: SizeConfig.height35,
                        child: FloatingActionButton(
                          heroTag: 'ABC',
                          child: const Icon(Icons.add, color: Colors.black87),
                          backgroundColor: Colors.white,
                          onPressed: () {
                            setState(() {
                              widget.menuItem.quantity++;
                            });
                          },
                        ),
                      )
                    ],
                  ),
                ),
                Expanded(
                  flex: 6,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      TextButton(
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Theme.of(context).primaryColorLight),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ))),
                        child: Text(
                          "Cancel",
                          style: Theme.of(context).textTheme.caption,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop(false);
                        },
                      ),
                      TextButton(
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Theme.of(context).primaryColorLight),
                            shape: MaterialStateProperty.all<
                                RoundedRectangleBorder>(RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(10),
                            ))),
                        child: Text(
                          "Add To Cart",
                          style: Theme.of(context).textTheme.caption,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop(true);
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
