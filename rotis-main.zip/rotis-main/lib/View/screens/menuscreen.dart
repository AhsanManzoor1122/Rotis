import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/Model/cart.dart';
import 'package:foodapp/Model/menuitems.dart';
import 'package:foodapp/Model/staticvariables.dart';
import 'package:foodapp/View/Model/sizeconfig.dart';
import 'package:foodapp/View/screens/addonscreen.dart';

class MenuScreen extends StatefulWidget {
  int selectedMenuIndex = 0;

  MenuScreen({Key? key}) : super(key: key);

  @override
  _MenuScreenState createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
          bottom: SizeConfig.height10,
          right: SizeConfig.width10,
          left: SizeConfig.width10),
      child: Column(
        children: [
          Container(
            height: SizeConfig.height110,
            padding: EdgeInsets.symmetric(vertical: SizeConfig.height5),
            alignment: Alignment.center,
            child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: StaticVariables.menuCategories.length,
                separatorBuilder: (context, index) =>
                    SizedBox(width: SizeConfig.width5),
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        widget.selectedMenuIndex = index;
                      });
                    },
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Theme.of(context).primaryColor,
                        ),
                        /*borderRadius:
                              const BorderRadius.only(bottomLeft: Radius.circular(20), bottomRight: Radius.circular(20))*/
                      ),
                      width: SizeConfig.width100,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Image.network(
                            StaticVariables.menuCategories[index].imageUrl!,
                            fit: BoxFit.cover,
                          ),
                          Text(
                            StaticVariables.menuCategories[index].name!,
                            style: Theme.of(context).textTheme.caption,
                          ),
                        ],
                      ),
                      /*child: TextButton(
                          style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Theme.of(context).primaryColorLight),
                              shape: MaterialStateProperty.all<
                                      RoundedRectangleBorder>(
                                  RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      side: BorderSide(
                                          color: Theme.of(context)
                                              .primaryColor)))),
                          onPressed: () {
                            setState(() {
                              widget.selectedMenuIndex = index;
                            });
                          },
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Expanded(
                                  flex: 2,
                                  child: Container(
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(StaticVariables
                                              .menuCategories[index].imageUrl),
                                          fit: BoxFit.cover,
                                        ),
                                      ),
                                      height: 35,
                                      width: 50,
                                      child: const SizedBox.shrink())),
                              const SizedBox(
                                height: 5,
                              ),
                              Expanded(
                                  flex: 1,
                                  child: Text(
                                    StaticVariables.menuCategories[index].name,
                                    style: Theme.of(context).textTheme.caption,
                                  )),
                            ],
                          )),*/
                    ),
                  );
                }),
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: SizeConfig.height5),
              alignment: Alignment.center,
              child: GridView.builder(
                  gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                      maxCrossAxisExtent: SizeConfig.width200,
                      childAspectRatio: 3 / 2,
                      crossAxisSpacing: SizeConfig.width10,
                      mainAxisSpacing: SizeConfig.height10),
                  itemCount: StaticVariables
                      .menuCategories[widget.selectedMenuIndex]
                      .categoryItems
                      .length,
                  itemBuilder: (BuildContext ctx, index) {
                    return InkWell(
                      splashColor: Colors.grey.shade200,
                      // Splash color
                      onTap: () async {
                        bool? res = false;
                        res =
                            await Navigator.of(context).push(MaterialPageRoute(
                          builder: (context) => AddOnScreen(
                              StaticVariables
                                  .menuCategories[widget.selectedMenuIndex]
                                  .categoryItems[index],
                              StaticVariables
                                  .menuCategories[widget.selectedMenuIndex]
                                  .categoryItems[index]
                                  .addOns),
                        ));
                        print(StaticVariables
                            .menuCategories[widget.selectedMenuIndex]
                            .categoryItems[index]
                            .quantity);
                        if (res != null && res == true) {
                          MenuItems temp1 = StaticVariables
                              .menuCategories[widget.selectedMenuIndex]
                              .categoryItems[index]
                              .getDeepCopy();
                          temp1.calculatePriceAddOns();
                          Cart.cartItems.add(temp1);
                          ScaffoldMessenger.of(context)
                              .showSnackBar(const SnackBar(
                            duration: Duration(milliseconds: 500),
                            content: Text("Item Added to Cart"),
                          ));
                          StaticVariables
                              .menuCategories[widget.selectedMenuIndex]
                              .categoryItems[index]
                              .quantity = 1;
                        }
                        // MenuItems temp1=StaticVariables
                        //     .menuCategories[
                        // widget.selectedMenuIndex]
                        //     .categoryItems[index].getDeepCopy();
                        //
                        // Cart.cartItems.add(temp1);

                        StaticVariables.menuCategories[widget.selectedMenuIndex]
                            .categoryItems[index]
                            .resetOptions();

                        print(Cart.cartItems);
                      },
                      child: Container(
                        width: SizeConfig.width200,
                        height: SizeConfig.height100,
                        padding: EdgeInsets.all(SizeConfig.height5),
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: Theme.of(context).primaryColor,
                          image: DecorationImage(
                            image: NetworkImage(StaticVariables
                                .menuCategories[widget.selectedMenuIndex]
                                .categoryItems[index]
                                .imageUrl!),
                            fit: BoxFit.cover,
                          ),
                          borderRadius:
                              BorderRadius.circular(SizeConfig.height10),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const SizedBox.shrink(),
                            Container(
                              decoration: BoxDecoration(
                                color: Theme.of(context).primaryColor,
                                borderRadius:
                                    BorderRadius.circular(SizeConfig.height10),
                              ),
                              padding: EdgeInsets.all(SizeConfig.height5),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  SizedBox(
                                    width: SizeConfig.width100,
                                    child: Text(
                                      StaticVariables
                                          .menuCategories[
                                              widget.selectedMenuIndex]
                                          .categoryItems[index]
                                          .name!,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                          fontSize: SizeConfig.width14,
                                          color: Theme.of(context)
                                              .primaryColorLight),
                                    ),
                                  ),
                                  Text(
                                    "Rs. " +
                                        StaticVariables
                                            .menuCategories[
                                                widget.selectedMenuIndex]
                                            .categoryItems[index]
                                            .price
                                            .toString(),
                                    style: TextStyle(
                                        fontSize: SizeConfig.width12,
                                        color: Theme.of(context)
                                            .primaryColorLight),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        /*child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: Image.network(
                                StaticVariables
                                    .menuCategories[widget.selectedMenuIndex]
                                    .categoryItems[index]
                                    .imageUrl,
                                fit: BoxFit.cover, height: 70,
                              ),
                            ),
                            */ /*Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  image: NetworkImage(StaticVariables
                                      .menuCategories[widget.selectedMenuIndex]
                                      .categoryItems[index]
                                      .imageUrl),
                                  fit: BoxFit.cover,
                                ),
                                borderRadius: BorderRadius.circular(5),
                              ),
                              height: 50,
                              width: 200,
                              child: SizedBox.shrink(),
                            ),*/ /*
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      StaticVariables
                                          .menuCategories[
                                              widget.selectedMenuIndex]
                                          .categoryItems[index]
                                          .name,
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: Theme.of(context)
                                              .primaryColorLight),
                                    ),
                                    Text(
                                      StaticVariables
                                          .menuCategories[
                                              widget.selectedMenuIndex]
                                          .categoryItems[index]
                                          .price
                                          .toString(),
                                      style: TextStyle(
                                          fontSize: 12,
                                          color: Theme.of(context)
                                              .primaryColorLight),
                                    ),
                                  ],
                                ),
                                ClipOval(
                                  child: Material(
                                    color: Theme.of(context)
                                        .primaryColorLight, // Button color
                                    child: InkWell(
                                      splashColor: Colors.grey.shade200,
                                      // Splash color
                                      onTap: () async {
                                        bool res = false;
                                        // if (StaticVariables
                                        //     .menuCategories[
                                        //         widget.selectedMenuIndex]
                                        //     .categoryItems[index]
                                        //     .addOns
                                        //     .isNotEmpty) {
                                        //
                                        // }else{
                                        //   res=true;
                                        // }
                                        res = await Navigator.of(context)
                                            .push(MaterialPageRoute(
                                          builder: (context) => AddOnScreen(
                                              StaticVariables
                                                  .menuCategories[
                                                      widget.selectedMenuIndex]
                                                  .categoryItems[index],
                                              StaticVariables
                                                  .menuCategories[
                                                      widget.selectedMenuIndex]
                                                  .categoryItems[index]
                                                  .addOns),
                                        ));
                                        print(StaticVariables
                                            .menuCategories[
                                                widget.selectedMenuIndex]
                                            .categoryItems[index]
                                            .quantity);
                                        if (res == true) {
                                          MenuItems temp1 = StaticVariables
                                              .menuCategories[
                                                  widget.selectedMenuIndex]
                                              .categoryItems[index]
                                              .getDeepCopy();
                                          temp1.calculatePriceAddOns();
                                          Cart.cartItems.add(temp1);
                                          ScaffoldMessenger.of(context)
                                              .showSnackBar(const SnackBar(
                                            duration: Duration(milliseconds: 500),
                                            content: Text("Item Added to Cart"),
                                          ));
                                        }
                                        // MenuItems temp1=StaticVariables
                                        //     .menuCategories[
                                        // widget.selectedMenuIndex]
                                        //     .categoryItems[index].getDeepCopy();
                                        //
                                        // Cart.cartItems.add(temp1);

                                        StaticVariables
                                            .menuCategories[
                                                widget.selectedMenuIndex]
                                            .categoryItems[index]
                                            .resetOptions();

                                        print(Cart.cartItems);
                                      },
                                      child: SizedBox(
                                          width: 25,
                                          height: 25,
                                          child: Icon(
                                            Icons.add,
                                            color: Theme.of(context).primaryColor,
                                          )),
                                    ),
                                  ),
                                )
                              ],
                            )
                          ],
                        ),*/
                      ),
                    );
                  }),
            ),
          ),
        ],
      ),
    );
  }
}
