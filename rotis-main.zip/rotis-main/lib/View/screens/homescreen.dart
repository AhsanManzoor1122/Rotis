import 'package:fluid_bottom_nav_bar/fluid_bottom_nav_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/Controller/apicalls.dart';
import 'package:foodapp/Model/response.dart';
import 'package:foodapp/Model/staticvariables.dart';
import 'package:foodapp/View/screens/cartscreen.dart';
import 'package:foodapp/View/screens/menuscreen.dart';
import 'package:foodapp/View/screens/orderscreen.dart';
import 'package:foodapp/View/widgets/end_drawer.dart';

import '../Model/shared_prefs.dart';
import '../Model/sizeconfig.dart';
import '../Model/staticviewvariables.dart';
import 'loginpage.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();

  Widget pageSelector() {
    if (StaticVariables.activeScreen == 1) {
      return CartScreen();
    } else if (StaticVariables.activeScreen == 2) {
      return OrdersScreen();
    } else if (StaticVariables.activeScreen == 0) {
      return MenuScreen();
    } else {
      return const Text("Error!");
      //return MenuScreen();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: scaffoldKey,
        backgroundColor: Theme.of(context).primaryColorLight,
        appBar: AppBar(
          bottomOpacity: 0.0,
          elevation: 0.0,
          leading: Padding(
            padding: EdgeInsets.symmetric(horizontal: SizeConfig.width10),
            child: SizedBox(
                height: SizeConfig.height50,
                width: SizeConfig.width50,
                child: const Image(image: AssetImage('assets/logo.png'))),
          ),
          backgroundColor: Theme.of(context).primaryColorLight,
          actions: [
            IconButton(
              icon: Icon(
                Icons.menu,
                color: Theme.of(context).primaryColor,
              ),
              onPressed: () {
                scaffoldKey.currentState!.openEndDrawer();
              },
            ),
          ],
        ),
        onEndDrawerChanged: (bool x) {
          if (x == false) {
            setState(() {});
          }
        },
        endDrawer: EndDrawer(
          logoutTap: () async {
            setState(() {
              StaticViewVariables.showLoaderDialog(context);
            });
            Response r = await ApiCalls.logOut();
            setState(() {
              Navigator.of(context).pop();
              //print(StaticVariables.selectedTableIdOrderScreen);
            });
            if (r.status == true) {
              SharedPrefs.saveUserData(token: "");
              Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (context) => LoginPage(),
              ));
            }
          },
        ),
        bottomNavigationBar: Builder(
          builder: (context) => FluidNavBar(
            // (1)
            icons: [
              // (2)
              FluidNavBarIcon(svgPath: "assets/home.svg"), // (3)
              FluidNavBarIcon(svgPath: "assets/cart.svg"),
              FluidNavBarIcon(svgPath: "assets/order.svg"),
              //FluidNavBarIcon(svgPath: "assets/nav.svg"),
            ],
            animationFactor: 0.5,
            scaleFactor: 2.0,
            defaultIndex: 0,
            style: FluidNavBarStyle(
                barBackgroundColor: Theme.of(context).primaryColor,
                iconBackgroundColor: Colors.white,
                iconSelectedForegroundColor: Theme.of(context).primaryColor,
                iconUnselectedForegroundColor: Theme.of(context).primaryColor),
            onChange: (int x) {
              /*if (x == 3) {
                Scaffold.of(context).openEndDrawer();
              } else {
                StaticVariables.activeScreen = x;
              }*/
              setState(() {
                StaticVariables.activeScreen = x;
              });
            }, // (4)
          ),
        ),
        body: pageSelector());
  }
}
