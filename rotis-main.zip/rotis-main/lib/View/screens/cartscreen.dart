import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/Model/cart.dart';
import 'package:foodapp/Model/response.dart';
import 'package:foodapp/Model/staticvariables.dart';
import 'package:foodapp/View/Model/staticviewvariables.dart';

import '../Model/sizeconfig.dart';

class CartScreen extends StatefulWidget {
  CartScreen({Key? key}) : super(key: key) {
    Cart.calculateTotalItemPrice();
    Cart.calculateTaxAmount();
    Cart.calculateTotalAmount();
  }

  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          flex: 1,
          child: Container(
              padding: EdgeInsets.symmetric(vertical: SizeConfig.height5),
              alignment: Alignment.center,
              child: StaticVariables.waiterMode == true
                  ? ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: StaticVariables.allTables.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Padding(
                          padding: EdgeInsets.symmetric(
                              horizontal: SizeConfig.width5),
                          child: TextButton(
                            style: ButtonStyle(
                                backgroundColor: StaticVariables
                                            .selectedTableIdCartScreen ==
                                        StaticVariables.allTables[index].id
                                            .toString()
                                    ? MaterialStateProperty.all<Color>(
                                        Theme.of(context).primaryColor)
                                    : MaterialStateProperty.all<Color>(
                                        Theme.of(context).primaryColorLight),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(
                                            SizeConfig.height10),
                                        side:
                                            BorderSide(color: Theme.of(context).primaryColor)))),
                            onPressed: () {
                              setState(() {
                                StaticVariables.selectedTableIdCartScreen =
                                    StaticVariables.allTables[index].id
                                        .toString();
                                /*print(
                                    StaticVariables.selectedTableIdCartScreen);*/
                              });
                            },
                            child: Text(
                              StaticVariables.allTables[index].name!,
                              style:
                                  StaticVariables.selectedTableIdCartScreen ==
                                          StaticVariables.allTables[index].id
                                              .toString()
                                      ? Theme.of(context).textTheme.button
                                      : Theme.of(context).textTheme.caption,
                            ),
                          ),
                        );
                      })
                  : Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: SizeConfig.width5),
                      child: TextButton(
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                Theme.of(context).primaryColor),
                            shape: MaterialStateProperty.all<
                                    RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(
                                        SizeConfig.height10),
                                    side: BorderSide(
                                        color:
                                            Theme.of(context).primaryColor)))),
                        onPressed: () async {},
                        child: Text(
                          "Table ${StaticVariables.selectedTableIdCartScreen}",
                          style: Theme.of(context).textTheme.button,
                        ),
                      ),
                    )),
        ),
        Padding(
          padding: EdgeInsets.symmetric(vertical: SizeConfig.height10),
          child: const Text("Items in Cart"),
        ),
        Expanded(
          flex: 6,
          child: Cart.cartItems.isEmpty
              ? const Center(
                  child: Text("Cart is empty"),
                )
              : Container(
                  padding: EdgeInsets.symmetric(vertical: SizeConfig.height5),
                  alignment: Alignment.center,
                  child: ListView.builder(
                      scrollDirection: Axis.vertical,
                      itemCount: Cart.cartItems.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Padding(
                          padding: EdgeInsets.symmetric(
                              vertical: SizeConfig.height5),
                          child: Container(
                            color: Theme.of(context).primaryColor,
                            padding: EdgeInsets.all(SizeConfig.height5),
                            child: Row(
                              children: [
                                SizedBox(
                                  height: SizeConfig.height35,
                                  width: SizeConfig.height35,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(15),
                                    child: Image.network(
                                      Cart.cartItems[index].imageUrl!,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                SizedBox(width: SizeConfig.width10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        Cart.cartItems[index].name!,
                                        style:
                                            Theme.of(context).textTheme.button,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      Text(
                                        Cart.cartItems[index].pricePlusAddOns
                                            .toString(),
                                        style:
                                            Theme.of(context).textTheme.button,
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: SizeConfig.width170,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      TextButton(
                                        style: ButtonStyle(
                                            backgroundColor:
                                                MaterialStateProperty.all<
                                                    Color>(Colors.white),
                                            shape: MaterialStateProperty.all<
                                                    RoundedRectangleBorder>(
                                                RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      SizeConfig.height5),
                                            ))),
                                        onPressed: () {
                                          setState(() {
                                            Cart.cartItems[index].takeaway =
                                                !Cart.cartItems[index].takeaway;
                                          });
                                        },
                                        child: Text(
                                          Cart.cartItems[index].takeaway ==
                                                  false
                                              ? "Take Away"
                                              : "Dine In",
                                          style: Theme.of(context)
                                              .textTheme
                                              .caption,
                                        ),
                                      ),
                                      IconButton(
                                        icon: Icon(
                                          Icons.delete,
                                          color: Theme.of(context)
                                              .primaryColorLight,
                                        ),
                                        onPressed: () {
                                          setState(() {
                                            Cart.cartItems.removeAt(index);
                                          });
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      }),
                ),
        ),
        Expanded(
          flex: 3,
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: SizeConfig.width40),
            child: Column(
              children: [
                Padding(
                  padding: EdgeInsets.symmetric(vertical: SizeConfig.height10),
                  child: Text(
                    "Summary",
                    style: TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontWeight: FontWeight.bold,
                      fontSize: SizeConfig.width18,
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("ITEM TOTAL PRICE"),
                    Text(Cart.totalItemPrice.toString()),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(StaticVariables.taxTitle!),
                    Text(Cart.totalTaxPrice.toString()),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text("TOTAL"),
                    Text(Cart.totalAmount.toString()),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: TextButton(
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                            Theme.of(context).primaryColor),
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(SizeConfig.height10),
                        ))),
                    onPressed: () async {
                      if (Cart.cartItems.isNotEmpty) {
                        if (StaticVariables.selectedTableIdCartScreen != "") {
                          setState(() {
                            StaticViewVariables.showLoaderDialog(context);
                          });
                          Response response = await Cart.placeOrder(
                              StaticVariables.selectedTableIdCartScreen);
                          if (response.status == true) {
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                              content: Text(response.message),
                            ));

                            setState(() {
                              Cart.emptyCart();
                              Navigator.of(context).pop();
                            });
                          } else {
                            setState(() {
                              Navigator.of(context).pop();
                            });
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                                content: Text(
                              response.message,
                            )));
                          }
                        } else {
                          ScaffoldMessenger.of(context)
                              .showSnackBar(const SnackBar(
                            content: Text("Please Select Table First"),
                          ));
                        }
                      } else {
                        ScaffoldMessenger.of(context)
                            .showSnackBar(const SnackBar(
                          content: Text("Cart is empty"),
                        ));
                      }
                    },
                    child: Text(
                      "Place Order",
                      style: Theme.of(context).textTheme.button,
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
      ],
    );
  }
}
