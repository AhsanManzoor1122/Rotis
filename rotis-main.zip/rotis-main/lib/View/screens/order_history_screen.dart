import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/Model/allorders.dart';
import 'package:foodapp/Model/response.dart';
import 'package:foodapp/Model/staticvariables.dart';
import 'package:foodapp/View/Model/sizeconfig.dart';
import 'package:foodapp/View/Model/staticviewvariables.dart';
import 'package:foodapp/View/widgets/expandablebutton.dart';

class OrderHistoryScreen extends StatefulWidget {
  bool todayOnly = false;

  OrderHistoryScreen({Key? key, required this.todayOnly}) : super(key: key);

  @override
  _OrderHistoryScreenState createState() => _OrderHistoryScreenState();
}

class _OrderHistoryScreenState extends State<OrderHistoryScreen> {
  @override
  void initState() {
    Timer(const Duration(seconds: 1), () async {
      if (StaticVariables.waiterMode) {
        if (StaticVariables.allTables.isNotEmpty) {
          getOrderList(index: 0);
        }
      } else {
        getOrderList();
      }
    });
    super.initState();
  }

  Future<void> getOrderList({int? index}) async {
    if (index != null) {
      StaticVariables.selectedTableIdOrderScreen =
          StaticVariables.allTables[index].id.toString();
    }
    setState(() {
      StaticViewVariables.showLoaderDialog(context);
    });
    Response r = await AllOrders.getAllOrders(
        StaticVariables.selectedTableIdOrderScreen, widget.todayOnly ? 1 : 0);
    if (r.status == true) {
      setState(() {
        AllOrders.calculateTotalValues();
        Navigator.of(context).pop();
        /*print(StaticVariables
                                      .selectedTableIdOrderScreen);*/
      });
    } else {
      setState(() {
        Navigator.of(context).pop();
      });
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
        r.message,
      )));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        bottomOpacity: 0.0,
        elevation: 0.0,
        leading: BackButton(
          color: Theme.of(context).primaryColor,
        ),
        backgroundColor: Theme.of(context).primaryColorLight,
        actions: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: SizeConfig.width10),
            child: SizedBox(
                height: SizeConfig.height45,
                width: SizeConfig.width45,
                child: const Image(image: AssetImage('assets/logo.png'))),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              flex: 1,
              child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  alignment: Alignment.center,
                  child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: StaticVariables.allTables.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          child: TextButton(
                            style: ButtonStyle(
                                backgroundColor: StaticVariables
                                            .selectedTableIdOrderScreen ==
                                        StaticVariables.allTables[index].id
                                            .toString()
                                    ? MaterialStateProperty.all<Color>(
                                        Theme.of(context).primaryColor)
                                    : MaterialStateProperty.all<Color>(
                                        Theme.of(context).primaryColorLight),
                                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                                    RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        side: BorderSide(
                                            color:
                                                Theme.of(context).primaryColor)))),
                            onPressed: () => getOrderList(index: index),
                            child: Text(
                              StaticVariables.allTables[index].name!,
                              style:
                                  StaticVariables.selectedTableIdOrderScreen ==
                                          StaticVariables.allTables[index].id
                                              .toString()
                                      ? Theme.of(context).textTheme.button
                                      : Theme.of(context).textTheme.caption,
                            ),
                          ),
                        );
                      })),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text(
                widget.todayOnly ? "Today's Orders List" : "Orders History",
                style: TextStyle(
                  fontSize: SizeConfig.width18,
                  fontWeight: FontWeight.bold,
                  decoration: TextDecoration.underline,
                  decorationColor: Theme.of(context).primaryColor,
                  decorationThickness: 3,
                ),
              ),
            ),
            Expanded(
              flex: 6,
              child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  alignment: Alignment.center,
                  child: AllOrders.listOrders.isEmpty
                      ? const Center(
                          child: Text("No orders found"),
                        )
                      : ListView.builder(
                          scrollDirection: Axis.vertical,
                          itemCount: AllOrders.listOrders.length,
                          itemBuilder: (BuildContext context, int index) {
                            return Padding(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 5),
                                //child: Text("gey"),
                                child: ExpandableButton(index));
                          })),
            ),
            Expanded(
              flex: 3,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Text(
                        "Summary",
                        style: TextStyle(
                          fontSize: SizeConfig.width18,
                          fontWeight: FontWeight.bold,
                          decoration: TextDecoration.underline,
                          decorationColor: Theme.of(context).primaryColor,
                          decorationThickness: 3,
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Sub-total"),
                        Text(AllOrders.totalItemsValue.toString()),
                      ],
                    ),
                    const Divider(thickness: 1),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(StaticVariables.taxTitle![0].toUpperCase() +
                            StaticVariables.taxTitle!
                                .substring(1)
                                .toLowerCase()),
                        Text(AllOrders.totalTaxValue.toString()),
                      ],
                    ),
                    const Divider(thickness: 1),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text("Service Charges"),
                        Text(AllOrders.totalServiceCharges.toString()),
                      ],
                    ),
                    const Divider(thickness: 1),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Total",
                          style: TextStyle(
                            fontSize: SizeConfig.width16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          AllOrders.totalBillValue.toString(),
                          style: TextStyle(
                            fontSize: SizeConfig.width16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
