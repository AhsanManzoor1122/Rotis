import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:foodapp/Controller/apicalls.dart';
import 'package:foodapp/Model/menucategory.dart';
import 'package:foodapp/Model/response.dart';
import 'package:foodapp/Model/staticvariables.dart';
import 'package:foodapp/Model/tables.dart';
import 'package:foodapp/View/Model/shared_prefs.dart';
import 'package:foodapp/View/Model/staticviewvariables.dart';

import '../Model/sizeconfig.dart';
import 'homescreen.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  String password = "";
  TextEditingController enteredUserName = TextEditingController();
  TextEditingController enteredPassword = TextEditingController();
  bool progressStatus = false;

  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 1), () async {
      checkToken();
    });
  }

  Future<void> checkToken() async {
    setState(() {
      StaticViewVariables.showLoaderDialog(context);
    });
    SharedPrefs.getUserData();
    Response response = await ApiCalls.checkToken();

    if (response.status == true) {
      Response response2 = await ApiCalls.getMenuDetails();
      if (response2.status == true) {
        List<dynamic> allCategories = response2.data['menus'];
        for (int a = 0; a < allCategories.length; a++) {
          MenuCategory mCategory = MenuCategory();
          mCategory.fromJson(allCategories[a]);
          StaticVariables.menuCategories.add(mCategory);
        }

        if (StaticVariables.waiterMode) {
          List<dynamic> allTables = response2.data['tables'];
          for (int a = 0; a < allTables.length; a++) {
            Tables table = Tables();
            table.fromJson(allTables[a]);
            StaticVariables.allTables.add(table);
          }
        }

        //print(StaticVariables.allTables);
        StaticVariables.getContactDetails();
        Navigator.of(context).pop();
        Navigator.of(context).pushReplacement(MaterialPageRoute(
          builder: (context) => const HomeScreen(),
        ));
      } else {
        setState(() {
          Navigator.of(context).pop();
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(response2.message),
        ));
      }
    } else {
      setState(() {
        Navigator.of(context).pop();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: SingleChildScrollView(
        child: Container(
          alignment: Alignment.center,
          height: SizeConfig.screenHeight,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                  height: SizeConfig.height150,
                  width: SizeConfig.width150,
                  decoration: BoxDecoration(
                      color: Theme.of(context).primaryColorLight,
                      shape: BoxShape.circle),
                  padding: EdgeInsets.all(SizeConfig.height20),
                  child: Image.asset('assets/logo.png')),
              SizedBox(
                height: SizeConfig.height30,
              ),
              ClipPath(
                clipper: _MyClipper(),
                child: Container(
                  height: SizeConfig.height350,
                  width: SizeConfig.screenWidth - SizeConfig.width40,
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColorLight,
                    borderRadius:
                        BorderRadius.all(Radius.circular(SizeConfig.height20)),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        "Login",
                        style: TextStyle(
                          fontSize: SizeConfig.width20,
                          color: Theme.of(context).primaryColor,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.width30),
                        child: TextFormField(
                          //textAlign: TextAlign.center,
                          decoration: const InputDecoration(
                              //border: InputBorder.none,
                              hintText: "Enter Username"),
                          controller: enteredUserName,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.width30),
                        child: TextFormField(
                          //textAlign: TextAlign.center,
                          decoration: const InputDecoration(
                              //border: InputBorder.none,
                              hintText: "Enter Password"),
                          controller: enteredPassword,
                          obscureText: true,
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: SizeConfig.width20),
                        alignment: Alignment.bottomRight,
                        child: ElevatedButton(
                          child: Icon(
                            Icons.arrow_forward,
                            color: Theme.of(context).primaryColorLight,
                          ),
                          style: ElevatedButton.styleFrom(
                            shape: const CircleBorder(),
                            padding: EdgeInsets.all(SizeConfig.height10),
                            primary: Theme.of(context).primaryColor,
                            onPrimary: Theme.of(context).primaryColorLight,
                          ),
                          onPressed: () async {
                            FocusScope.of(context).unfocus();

                            if (enteredUserName.text.isNotEmpty &
                                enteredPassword.text.isNotEmpty) {
                              //check widget.enteredPassword.text== widget.password
                              setState(() {
                                StaticViewVariables.showLoaderDialog(context);
                              });
                              Response response = await ApiCalls.getUserDetails(
                                  username: enteredUserName.text.trim(),
                                  password: enteredPassword.text.trim());

                              if (response.status == true) {
                                Map<String, dynamic> t1 = response.data["user"];
                                Response response2 =
                                    await ApiCalls.getMenuDetails();
                                if (response2.status == true) {
                                  List<dynamic> allCategories =
                                      response2.data['menus'];
                                  for (int a = 0;
                                      a < allCategories.length;
                                      a++) {
                                    MenuCategory mCategory = MenuCategory();
                                    mCategory.fromJson(allCategories[a]);
                                    StaticVariables.menuCategories
                                        .add(mCategory);
                                  }
                                  //print(StaticVariables.menuCategories);

                                  if (t1.containsKey("table_id")) {
                                    StaticVariables.waiterMode = false;
                                    StaticVariables.selectedTableIdCartScreen =
                                        t1["table_id"];
                                    StaticVariables.selectedTableIdOrderScreen =
                                        t1["table_id"];
                                    SharedPrefs.saveUserData(
                                        tableID: t1["table_id"],
                                        waiterMode: false);
                                  } else {
                                    SharedPrefs.saveUserData(waiterMode: true);
                                    StaticVariables.waiterMode = true;
                                    List<dynamic> allTables =
                                        response2.data['tables'];
                                    for (int a = 0; a < allTables.length; a++) {
                                      Tables table = Tables();
                                      table.fromJson(allTables[a]);
                                      StaticVariables.allTables.add(table);
                                    }
                                  }

                                  //print(StaticVariables.allTables);
                                  StaticVariables.getContactDetails();
                                  Navigator.of(context).pop();
                                  Navigator.of(context)
                                      .pushReplacement(MaterialPageRoute(
                                    builder: (context) => const HomeScreen(),
                                  ));
                                } else {
                                  setState(() {
                                    Navigator.of(context).pop();
                                  });
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(SnackBar(
                                    content: Text(response2.message),
                                  ));
                                }
                              } else {
                                setState(() {
                                  Navigator.of(context).pop();
                                });
                                ScaffoldMessenger.of(context)
                                    .showSnackBar(SnackBar(
                                  content: Text(response.message),
                                ));
                              }
                            } else {
                              ScaffoldMessenger.of(context)
                                  .showSnackBar(const SnackBar(
                                content: Text("Empty Fields"),
                              ));
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: SizeConfig.height30,
              ),
              Text(
                "Powered by ROTIS\nDesigned & Developed by Dev Dart Apps (Pvt) Ltd.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Theme.of(context).primaryColorLight),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MyClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();

    path.lineTo(0, 0);
    path.lineTo(0, size.height * 0.75);
    path.lineTo(size.width * 0.91, size.height);
    path.lineTo(size.width, size.height);
    path.lineTo(size.width, 0);

    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
