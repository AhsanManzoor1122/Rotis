import 'package:flutter/material.dart';
import 'package:foodapp/View/Model/sizeconfig.dart';

class BillDialog extends StatelessWidget {
  const BillDialog({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(SizeConfig.height25))),
      content: const Text("Your Printed Bill Is On Its Way"),
      actions: [
        // TextButton(
        //   child: const Text(
        //     "Cancel",
        //   ),
        //   onPressed: () {
        //     Navigator.of(context).pop(false);
        //   },
        // ),
        TextButton(
          child: const Text(
            "Okay",
            style: TextStyle(color: Colors.red),
          ),
          onPressed: () {
            Navigator.of(context).pop(true);
          },
        ),
      ],
    );
  }
}
