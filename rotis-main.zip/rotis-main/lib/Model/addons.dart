import 'package:foodapp/Model/option.dart';

class AddOns {
  int? id = 0;
  String? title = "";
  List<Option> options = [];

  void addOption(Option op) {
    options.add(op);
  }

  AddOns getDeepCopy() {
    AddOns a = AddOns();
    a.id! - id!;
    a.title = title;
    for (int i = 0; i < options.length; i++) {
      a.options.add(options[i].getDeepCopy());
    }
    return a;
  }

  void fromJson(dynamic data) {
    id = data['id'];
    title = data['title'];
    List<dynamic> op = data['options'];
    for (int a = 0; a < op.length; a++) {
      Option o = Option();
      o.fromJson(op[a]);
      options.add(o);
    }
  }
}
