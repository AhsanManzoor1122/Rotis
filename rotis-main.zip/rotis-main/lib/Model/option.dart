class Option {
  int? id = 0;
  String? name = "";
  String? descriptions = "";
  String? price = "";
  String? imageUrl = "";
  bool status = false;

  Option getDeepCopy() {
    Option o = Option();
    o.id = id;
    o.name = name;
    o.descriptions = descriptions;
    o.price = price;
    o.imageUrl = imageUrl;
    o.status = status;
    return o;
  }

  void fromJson(dynamic data) {
    id = data['id'];
    name = data['name'];
    descriptions = data['description'];
    price = data['price'];
    imageUrl = data['image'];
  }
}
