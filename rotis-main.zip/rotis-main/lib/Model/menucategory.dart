import 'package:foodapp/Model/menuitems.dart';

class MenuCategory {
  int? id = 0;
  String? name = "";
  String? imageUrl = "";
  List<MenuItems> categoryItems = [];

  void addItem(MenuItems item) {
    categoryItems.add(item);
  }

  void fromJson(dynamic data) {
    id = data['id'];
    name = data['name'];
    imageUrl = data['image'];
    List<dynamic> cItems = data['items'];
    for (int a = 0; a < cItems.length; a++) {
      MenuItems m = MenuItems();
      m.fromJson(cItems[a]);
      categoryItems.add(m);
    }
  }
}
