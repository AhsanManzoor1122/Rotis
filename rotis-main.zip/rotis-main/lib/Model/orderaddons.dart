import 'package:foodapp/Model/orderdetails.dart';

class OrderAddOns {
  int? id = 0;
  OrderDetails details = OrderDetails();
  String? totalValue = "";

  void fromJson(Map<String, dynamic> data) {
    id = data['id'];
    totalValue = data['total_value'];
    details.fromJson(data['details']);
  }
}
