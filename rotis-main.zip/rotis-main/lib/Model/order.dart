import 'package:foodapp/Model/orderitem.dart';

class Order {
  int? id = 0;
  String? orderStatus = "";
  String? tableId = "";
  bool? isRated = false;
  String? orderNo = "";
  String? totalValue = "";
  String? taxIncluded = "";
  String? taxValue = "";
  String? finalValue = "";
  String? serviceCharges = "";
  String? dateTime = "";
  List<OrderItem> itemsList = [];
  bool isSelected = true;

  void fromJson(Map<String, dynamic> tStatus) {
    // Map<String,dynamic> tStatus=data['data'];

    id = tStatus['id'];
    orderStatus = tStatus['status'];
    tableId = tStatus['table_id'];
    isRated = tStatus['is_rated'];
    orderNo = tStatus['order_no'];
    totalValue = tStatus['total_value'];
    taxIncluded = tStatus['tax_included'];
    taxValue = tStatus['tax_value'];
    finalValue = tStatus['final_value'];
    serviceCharges = tStatus['service_charges'];
    dateTime = tStatus['date_time'];
    List<dynamic> items = tStatus['items'];
    for (int i = 0; i < items.length; i++) {
      OrderItem o = OrderItem();
      o.fromJson(items[i]);
      itemsList.add(o);
    }
  }
}
