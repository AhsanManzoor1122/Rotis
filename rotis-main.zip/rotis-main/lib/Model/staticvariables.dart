import 'package:foodapp/Controller/apicalls.dart';
import 'package:foodapp/Model/menucategory.dart';
import 'package:foodapp/Model/response.dart';
import 'package:foodapp/Model/tables.dart';

class StaticVariables {
  static int activeScreen = 0;
  static int? taxPercentage = 0;
  static String? taxTitle = "";

  static bool waiterMode = false;

  //static String tableId="";

  static List<MenuCategory> menuCategories = [];
  static List<Tables> allTables = [];
  static String selectedTableIdCartScreen = "";
  static String selectedTableIdOrderScreen = "";

  void addToMenuCategory(MenuCategory mCategory) {
    menuCategories.add(mCategory);
  }

  static Future<void> getContactDetails() async {
    Response response1 = await ApiCalls.getContactDetails();
    if (response1.status == true) {
      List<dynamic> allContactDetails = response1.data;
      StaticVariables.taxTitle = allContactDetails[3]
          ["title"]; //assuming position of the tax remains same always in list
      StaticVariables.taxPercentage = int.parse(allContactDetails[3]["value"]);
      // print(StaticVariables.taxTitle);
      // print(StaticVariables.taxPercentage);
    } else {
      StaticVariables.taxTitle = "Error";
      StaticVariables.taxPercentage = 0;
    }
  }
}
