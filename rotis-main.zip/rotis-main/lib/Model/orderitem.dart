import 'package:foodapp/Model/orderaddons.dart';
import 'package:foodapp/Model/orderdetails.dart';

class OrderItem {
  int? id = 0;
  String? notes = "";
  String? quantity = "";
  String? itemValue = "";
  String? discount = "";
  String? totalValue = "";
  OrderDetails details = OrderDetails();
  List<OrderAddOns> addOnsList = [];

  void fromJson(Map<String, dynamic> data) {
    id = data['id'];
    notes = data['notes'];
    quantity = data['quantity'];
    itemValue = data['item_value'];
    discount = data['discount'];
    totalValue = data['total_value'];
    details.fromJson(data['details']);
    List<dynamic> aOns = data['addons'];
    for (int i = 0; i < aOns.length; i++) {
      OrderAddOns oAddOns = OrderAddOns();
      oAddOns.fromJson(aOns[i]);
      addOnsList.add(oAddOns);
    }
  }
}
