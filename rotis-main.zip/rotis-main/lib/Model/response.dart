class Response {
  String code = "0";
  bool status = false;
  String message = "";
  dynamic data;
}
