class OrderDetails {
  int? id = 0;
  String? name = "";
  String? description = "";
  String? price = "";
  String? imageUrl = "";

  void fromJson(Map<String, dynamic> data) {
    id = data['data'];
    name = data['name'];
    description = data['description'];
    if (data.containsKey('price')) {
      price = data['price'];
    }
    imageUrl = data['image'];
  }
}
