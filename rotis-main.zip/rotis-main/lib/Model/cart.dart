import 'package:foodapp/Controller/apicalls.dart';
import 'package:foodapp/Model/menuitems.dart';
import 'package:foodapp/Model/response.dart';
import 'package:foodapp/Model/staticvariables.dart';

class Cart {
  static List<MenuItems> cartItems = [];
  static double totalItemPrice = 0;
  static double totalTaxPrice = 0;
  static double totalAmount = 0;

  static void calculateTotalItemPrice() {
    totalItemPrice = 0;
    for (int a = 0; a < cartItems.length; a++) {
      totalItemPrice += cartItems[a].pricePlusAddOns;
    }
    totalItemPrice = double.parse(totalItemPrice.toStringAsFixed(2));
  }

  static void calculateTaxAmount() {
    totalTaxPrice = 0;
    totalTaxPrice = totalItemPrice * (StaticVariables.taxPercentage! / 100);
    totalTaxPrice = double.parse(totalTaxPrice.toStringAsFixed(2));
  }

  static void calculateTotalAmount() {
    totalAmount = 0;
    totalAmount += totalTaxPrice + totalItemPrice;
    totalAmount = double.parse(totalAmount.toStringAsFixed(2));
  }

  static void emptyCart() {
    cartItems.clear();
    totalItemPrice = 0;
    totalTaxPrice = 0;
    totalAmount = 0;
  }

  static Future<Response> placeOrder(String tableNo) async {
    Response r = await ApiCalls.placeOrder(tableNo);
    return r;
  }
}
