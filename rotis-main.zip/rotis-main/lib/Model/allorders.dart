import 'package:foodapp/Controller/apicalls.dart';
import 'package:foodapp/Model/response.dart';

import 'order.dart';

class AllOrders {
  static double totalBillValue = 0;
  static double totalItemsValue = 0;
  static double totalTaxValue = 0;
  static double totalServiceCharges = 0;

  static List<Order> listOrders = [];

  static Future<Response> getAllOrders(String tableId, int orderType) async {
    listOrders.clear();
    Response r = await ApiCalls.getOrderDetails(tableId, orderType);
    if (r.status == true) {
      List<dynamic>? allOrdersMap = r.data['data'];
      if (allOrdersMap != null) {
        for (int i = 0; i < allOrdersMap.length; i++) {
          Order o = Order();
          o.fromJson(allOrdersMap[i]);
          listOrders.add(o);
        }
      }
      return r;
    } else {
      return r;
    }

    //print(listOrders);
  }

  static void calculateTotalValues() {
    totalBillValue = 0;
    totalItemsValue = 0;
    totalTaxValue = 0;
    totalServiceCharges = 0;
    for (int a = 0; a < listOrders.length; a++) {
      if (listOrders[a].isSelected) {
        totalItemsValue += double.parse(listOrders[a].totalValue!);
        totalTaxValue += double.parse(listOrders[a].taxValue!);
        totalBillValue += double.parse(listOrders[a].finalValue!);
        totalServiceCharges += double.parse(listOrders[a].serviceCharges!);
      }
    }
  }

  static String getSelectedIDsString() {
    String ids = "";
    for (Order order in listOrders) {
      if (order.isSelected) {
        ids += order.id!.toString() + ",";
      }
    }
    if (ids.isNotEmpty) {
      ids = ids.substring(0, ids.length - 1);
    }
    return ids;
  }
}
