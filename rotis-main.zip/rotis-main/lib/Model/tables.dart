class Tables {
  int? id = 0;
  String? name = "";
  String? imageUrl = "";

  void fromJson(dynamic data) {
    id = data['id'];
    name = data['name'];
    imageUrl = data['image'];
  }
}
