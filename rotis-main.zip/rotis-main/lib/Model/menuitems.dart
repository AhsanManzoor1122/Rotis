import 'package:foodapp/Model/addons.dart';

class MenuItems {
  int? id = 0;
  String? name = "";
  String? description = "";
  int? oldPrice = 0;
  int? price = 0;
  String? imageUrl = "";
  bool takeaway = false;
  double pricePlusAddOns = 0;
  List<AddOns> addOns = [];
  int quantity = 1;

  void addAddOns(AddOns ao) {
    addOns.add(ao);
  }

  MenuItems getDeepCopy() {
    MenuItems m = MenuItems();
    m.id = id;
    m.name = name;
    m.description = description;
    m.oldPrice = oldPrice;
    m.price = price;
    m.imageUrl = imageUrl;
    m.takeaway = takeaway;
    m.quantity = quantity;
    for (int i = 0; i < addOns.length; i++) {
      m.addOns.add(addOns[i].getDeepCopy());
    }
    return m;
  }

  void calculatePriceAddOns() {
    pricePlusAddOns = price!.toDouble();
    for (int i = 0; i < addOns.length; i++) {
      for (int j = 0; j < addOns[i].options.length; j++) {
        if (addOns[i].options[j].status == true) {
          pricePlusAddOns += double.parse(addOns[i].options[j].price!);
        }
      }
    }
    pricePlusAddOns = pricePlusAddOns * quantity;
  }

  void resetOptions() {
    for (int i = 0; i < addOns.length; i++) {
      for (int j = 0; j < addOns[i].options.length; j++) {
        addOns[i].options[j].status = false;
      }
    }
  }

  void fromJson(dynamic data) {
    id = data['id'];
    name = data['name'];
    description = data['description'];
    oldPrice = data['old_price'];
    price = data['price'];
    imageUrl = data['image'];
    if (data['addons'] != null) {
      List<dynamic> aOns = data['addons'];
      for (int a = 0; a < aOns.length; a++) {
        AddOns aO = AddOns();
        aO.fromJson(aOns[a]);
        addOns.add(aO);
      }
    }
  }

  Map<String, dynamic> toJsonOrderFormat() {
    List<Map<String, dynamic>> aons = [];
    for (int a = 0; a < addOns.length; a++) {
      for (int b = 0; b < addOns[a].options.length; b++) {
        if (addOns[a].options[b].status == true) {
          aons.add({'id': addOns[a].options[b].id});
        }
      }
    }
    // print(aons);
    // print("Quantity $quantity");
    Map<String, dynamic> order = {
      'item_id': id,
      'quantity': quantity, //quantity right now
      'notes': '',
      'addons': aons,
    };

    //print(order);

    return order;
  }
}
